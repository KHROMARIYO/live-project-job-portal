import { useState, useEffect } from "react";
import swal from "sweetalert";

const ManageProfile = () =>{
    let[fname, pickName] = useState("");
    let[mobile, pickMobile] = useState("");
    let[email, pickEmail] = useState("");
    let[password, pickPassword] = useState("");

    const getUserDetails = () =>{
        let url = "http://localhost:1234/account/"+localStorage.getItem("id");
        fetch(url)
        .then(response=>response.json())
        .then(info=>{
            pickName( info.fullName );
            pickMobile( info.mobile );
            pickEmail( info.email );
            pickPassword( info.password );
        })
    }

    useEffect(()=>{
        getUserDetails();
    }, []);

    return(
        <div className="container mt-4">
            <div className="row">
                <div className="col-lg-6">
                    <h3 className="text-center mb-3"> Edit Profile </h3>
                    <div className="row mb-4">
                        <div className="col-lg-6 mb-4">
                            <p> Full Name </p>
                            <input type="text" className="form-control"/>
                        </div>
                        <div className="col-lg-6 mb-4">
                            <p> Mobile No </p>
                            <input type="number" className="form-control"/>
                        </div>
                        <div className="col-lg-6 mb-4">
                            <p> e-Mail Id </p>
                            <input type="email" className="form-control"/>
                        </div>
                        <div className="col-lg-6 mb-4">
                            <p> Password </p>
                            <input type="number" className="form-control"/>
                        </div>
                        <div className="col-lg-12 text-center">
                            <button className="btn btn-primary"> Update Profile </button>
                        </div>
                    </div>
                </div>
                <div className="col-lg-6">
                    <h3 className="text-center mb-3"> View Profile </h3>
                </div>
            </div>
        </div>
    )
}

export default ManageProfile;